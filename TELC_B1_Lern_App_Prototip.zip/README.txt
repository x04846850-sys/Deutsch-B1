TELC B1 Lern-App — dastlabki prototip

Ishga tushirish:
1) ZIP faylni oching.
2) index.html faylini Chrome yoki boshqa zamonaviy brauzerda oching.
3) Telefon va kompyuter ekraniga moslashadi.
4) Internetga joylashtirilganda HTTPS orqali PWA sifatida bosh ekranga qo‘shish mumkin.

Eslatma:
- Mashqlar hozircha demo materiallar; rasmiy TELC savollari emas.
- Natijalar shu brauzer/qurilmadagi localStorage ichida saqlanadi.
- Ovozli o‘qish qurilmadagi Speech Synthesis ovozlariga bog‘liq.
- Bu hali Google Play yoki App Store uchun tayyor native paket emas. Keyingi bosqichda hosting va Android/iOS paketlash kerak bo‘ladi.
